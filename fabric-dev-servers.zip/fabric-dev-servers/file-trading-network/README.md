# file-trading-network

A Permission sharing Hyperledger Network
